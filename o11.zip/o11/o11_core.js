/*
*********************************************
* CORE OBJECTS
*********************************************
*/

"use strict";

let globalobjid = 0;


/* 
*************************************************************************
* Object O11CORE_prop
*************************************************************************
*/
class O11CORE_prop {
  constructor() {
    this.value = undefined;
  }
  
  set(value) {
    this.value = value;
  }
  
  get() {
    return this.value;
  }
} // end O11CORE_prop


/* 
*************************************************************************
* Object O11CORE_obj
*************************************************************************
*/
class O11CORE_obj {
  constructor() {
    this.p_id = new O11CORE_prop();
    this.p_parentid = new O11CORE_prop();
    this.p_name = new O11CORE_prop();
    this.p_type = new O11CORE_prop(); 

    // object properties defaults  
    this.p_id.set(undefined);
    this.p_parentid.set(undefined);
    this.p_name.set("obj");
    this.p_type.set(""); 
  }
    
  set_div(id, parentid) {
    let parentcontainer, newcontainer, att;

    if (parentid === undefined) {
      parentcontainer = document.getElementById("body");
      this.p_parentid.set("body");
    } else {
      parentcontainer = document.getElementById(parentid);
      this.p_parentid.set(parentid);
    }

    newcontainer = document.createElement("div");
    att = document.createAttribute("id");

    att.value = id;

    newcontainer.setAttributeNode(att);
    parentcontainer.appendChild(newcontainer);
  }  
} // end O11CORE_obj


/* 
*************************************************************************
* Object O11CORE_size
*************************************************************************
*/
class O11CORE_size {
  constructor() { 
    this.p_width = new O11CORE_prop(); // px %
    this.p_height = new O11CORE_prop(); // px %
    this.p_boxsizing = new O11CORE_prop();
  
    // object properties defaults
    this.p_width.set(""); // px %
    this.p_height.set(""); // px %
    this.p_boxsizing.set("border-box"); // doesn't include margin
  }
  
  set_prop2container(container) {
    container.style.width = this.p_width.get();
    container.style.height = this.p_height.get();
    container.style.boxSizing = this.p_boxsizing.get();
  }  
  
} // end O11CORE_size


/* 
*************************************************************************
* Object O11CORE_backimage
*************************************************************************
*/
class O11CORE_backimage {
 
  constructor() {
    this.p_position = new O11CORE_prop();
    this.p_size = new O11CORE_prop();
    this.p_repeat = new O11CORE_prop(); 
    this.p_filepath = new O11CORE_prop();
  
    // object properties defaults
    this.p_position.set("");
    this.p_size.set("");
    this.p_repeat.set("no-repeat"); // no-repeat | repeat
    this.p_filepath.set("");
  }
  
  set_prop2container(container) {
    container.style.backgroundRepeat = this.p_repeat.get();
    container.style.backgroundPosition = this.p_position.get();
    container.style.backgroundSize = this.p_size.get();
    container.style.backgroundImage = "url('" + this.p_filepath.get() + "')";
  }
}  
// end O11CORE_backimage


/* 
*************************************************************************
* Object O11CORE_color
*************************************************************************
*/
class O11CORE_color {

  constructor() {
    this.p_rgbacolor="";

    // object properties defaults
    this.p_rgbacolor="rgba(0,0,0,1.0)";
  }

  set_rgbacolor(newred, newgreen, newblue, newtransparency) {
    
    this.p_rgbacolor = "rgba(" + newred + "," + newgreen + "," + newblue + "," + newtransparency + ")";
    
  }
  
  get_rgbacolor() {
    return this.p_rgbacolor;
  }
   
  
  set_color(newnamecolor, newtransparency) {
    let red, green, blue, transparency;  

    /*
    if (newtransparency===undefined) {
      this.p_rgbacolor = newnamecolor;
    }
    */  
       
    this.p_rgbacolor = newnamecolor;
    ///this.p_rgbacolor = "rgba(" + red + "," + green + "," + blue + "," + transparency + ")";
    
  }
 
  set_prop2container(container) {
    container.style.color = this.p_rgbacolor;
  }
}
// end O11CORE_color


/* 
*************************************************************************
* Object O11CORE_backcolor
*************************************************************************
*/
class O11CORE_backcolor extends O11CORE_color {

  set_prop2container(container) {
    container.style.backgroundColor = this.p_rgbacolor;
  }
} 
// end O11CORE_backcolor


/* 
*************************************************************************
* Object O11CORE_align
*************************************************************************
*/
class O11CORE_align {
  constructor() {

    this.p_position = new O11CORE_prop();
    this.p_zindex = new O11CORE_prop();

    this.p_locate = new O11CORE_prop();
    this.p_top = new O11CORE_prop();
    this.p_bottom = new O11CORE_prop();
    this.p_right = new O11CORE_prop(); 
    this.p_left = new O11CORE_prop();
    this.p_transform = new O11CORE_prop();
    this.p_float = new O11CORE_prop();

    this.p_margintop = new O11CORE_prop(); 
    this.p_marginbottom = new O11CORE_prop(); 
    this.p_marginleft = new O11CORE_prop(); 
    this.p_marginright = new O11CORE_prop(); 

    this.p_paddingtop = new O11CORE_prop(); 
    this.p_paddingbottom = new O11CORE_prop();
    this.p_paddingleft = new O11CORE_prop();
    this.p_paddingright = new O11CORE_prop();
  
    // object properties defaults

    this.p_locate.set("");
    // float
    // topleft, topmiddle, topright
    // middleleft, middle, middleright
    // bottomleft, bottommiddle, bottomright

    this.p_position.set("absolute"); // fixed relative absolute
    this.p_zindex.set(0);
    
    this.p_top.set("0px"); // px
    this.p_bottom.set("0px"); // px
    this.p_right.set("0px"); // px
    this.p_left.set("0px"); // px
    this.p_transform.set("");  
    this.p_float.set("left"); // left right none

    this.p_margintop.set("0px"); // auto px
    this.p_marginbottom.set("0px"); // auto px
    this.p_marginleft.set("auto"); // auto px
    this.p_marginright.set("auto"); // auto px

    this.p_paddingtop.set("0px"); // px
    this.p_paddingbottom.set("0px"); // px
    this.p_paddingleft.set("0px"); // px
    this.p_paddingright.set("0px"); // px

  }

  subtract_px(px1, px2) {
    let result;
    let res;
    
    res = parseInt(px1,10) - parseInt(px2,10);

    result = res.toString() + "px";
          
    return result;
  }

  add_px(px1, px2) {
    let result;
    let res;
    
    res = parseInt(px1,10) + parseInt(px2,10);

    result = res.toString() + "px";
          
    return result;
  }


  set_locate(locate) {
    
    if (locate === "topleft") {
        this.p_top.set("0px");
        this.p_bottom.set("");
        this.p_left.set("0px");
        this.p_right.set("");
        this.p_transform.set("translate(0%, 0%)");
        this.p_locate.set("topleft");
    }

    if (locate === "topcenter") {
        this.p_top.set("0px");
        this.p_bottom.set("");
        this.p_left.set("50%");
        this.p_right.set("");
        this.p_transform.set("translate(-50%, 0%)");
        this.p_locate.set("topcenter");
    }

    if (locate === "topright") {
        this.p_top.set("0px");
        this.p_bottom.set("");
        this.p_left.set("");
        this.p_right.set("0px");
        this.p_transform.set("translate(0%, 0%)");
        this.p_locate.set("topright");
    }

    if (locate === "middleleft") {
        this.p_top.set("50%");
        this.p_bottom.set("");
        this.p_left.set("0px");
        this.p_right.set("");
        this.p_transform.set("translate(0%, -50%)");
        this.p_locate.set("middleleft");
    }

    if (locate === "middlecenter") {
        this.p_top.set("50%");
        this.p_bottom.set("");
        this.p_left.set("50%");
        this.p_right.set("");
        this.p_transform.set("translate(-50%, -50%)");
        this.p_locate.set("middlecenter");
    }

    if (locate === "middleright") {
        this.p_top.set("50%"); 
        this.p_bottom.set("");
        this.p_left.set("");
        this.p_right.set("0px");
        this.p_transform.set("translate(0%, -50%)");
        this.p_locate.set("middleright");
    }

    if (locate === "bottomleft") {
        this.p_top.set("");
        this.p_bottom.set("0px");
        this.p_left.set("0px");
        this.p_right.set("");
        this.p_transform.set("translate(0%, 0%)");
        this.p_locate.set("bottomleft");
    }

    if (locate === "bottomcenter") {
        this.p_top.set("");
        this.p_bottom.set("0px");
        this.p_left.set("50%");
        this.p_right.set("");
        this.p_transform.set("translate(-50%, 0%)");
        this.p_locate.set("bottomcenter");
    }

    if (locate === "bottomright") {
        this.p_top.set("");
        this.p_bottom.set("0px");
        this.p_left.set("");
        this.p_right.set("0px");
        this.p_transform.set("translate(0%, 0%)");
        this.p_locate.set("bottomright");
    }
  }

  set_prop2container(container) {

    if (this.p_position.get() === "fixed") {
      container.style.top = this.p_top.get();
      container.style.bottom = this.p_bottom.get();
      container.style.right = this.p_right.get();
      container.style.left = this.p_left.get();
      container.style.transform = this.p_transform.get();
    }  

    if (this.p_position.get() === "absolute") {
      container.style.top = this.p_top.get();
      container.style.bottom = this.p_bottom.get();
      container.style.right = this.p_right.get();
      container.style.left = this.p_left.get();
      container.style.transform = this.p_transform.get();
    }

    if (this.p_position.get() === "relative") {
      container.style.float = this.p_float.get();
      container.style.marginTop = this.p_margintop.get();
      container.style.marginBottom = this.p_marginbottom.get();
      container.style.marginRight = this.p_marginright.get();
      container.style.marginLeft = this.p_marginleft.get();
    }
    
    container.style.position = this.p_position.get();
    container.style.zIndex = this.p_zindex.get();

    container.style.paddingTop = this.p_paddingtop.get();
    container.style.paddingBottom = this.p_paddingbottom.get();
    container.style.paddingLeft = this.p_paddingleft.get();
    container.style.paddingRight = this.p_paddingright.get();

  }
  
}
// end O11CORE_align


/* 
*************************************************************************
* Object O11CORE_image
*************************************************************************
*/
class O11CORE_image {

  constructor() {
    this.p_filepath = new O11CORE_prop();
    this.p_width = new O11CORE_prop();
    this.p_height = new O11CORE_prop();
    this.p_alt = new O11CORE_prop();

    // object properties defaults
    this.p_width.set("32px");
    this.p_height.set("32px");
    this.p_alt.set("image");
    this.p_filepath.set("");
  }

  set_prop2container(container) {
    let image;

    image = document.createElement("IMG");

    image.setAttribute("width", this.p_witdh.get());
    image.setAttribute("height", this.p_height.get());
    image.setAttribute("alt", this.p_alt.get());
    image.setAttribute("src", this.p_filepath.get());

    container.appendChild(image);
  }
} 
// O11CORE_image


/* 
*************************************************************************
* Object O11CORE_video
*************************************************************************
*/
class O11CORE_video {

  constructor() {
    this.p_filepath = new O11CORE_prop();
    this.p_width = new O11CORE_prop();
    this.p_height = new O11CORE_prop();
    this.p_autoplay = new O11CORE_prop();
    this.p_loop = new O11CORE_prop();
    this.p_controls = new O11CORE_prop();
    this.p_type = new O11CORE_prop();
    
    // object properties defaults
    this.p_width.set("100%");
    this.p_height.set("auto");
    this.p_autoplay.set("true");
    this.p_loop.set("true");
    this.p_controls.set("false");
    this.p_type.set("video/mp4");
    this.p_filepath.set("");
   }

  set_prop2container(container) {
    let video, source;
    
    video = document.createElement("VIDEO");
    source = document.createElement("SOURCE");

    source.setAttribute("src", this.p_filepath.get());    
    source.setAttribute("type", this.p_type.get());

    video.appendChild(source);

    video.setAttribute("width", this.p_width.get());
    video.setAttribute("height", this.p_height.get());
    video.autoplay = this.p_autoplay.get();
    video.loop = this.p_loop.get();
    video.controls = this.p_controls.get();

    container.appendChild(video);
  }
} 
// O11CORE_video


/* 
*************************************************************************
* Object O11CORE_audio
*************************************************************************
*/
class O11CORE_audio {

  constructor() {

    this.p_filepath = new O11CORE_prop();
    this.p_loop = new O11CORE_prop();
    this.p_autoplay = new O11CORE_prop();
    this.p_controls = new O11CORE_prop();
    this.p_type = new O11CORE_prop();

    // object properties defaults
    this.p_filepath.set("");
    this.p_loop.set(false); 
    this.p_autoplay.set(false); 
    this.p_controls.set(false);
    this.p_type.set("audio/mpeg");
    this.p_filepath.set("");
  }

  set_prop2container(container) {
    let audio, source;
             
    audio = document.createElement("AUDIO");
    source = document.createElement("SOURCE");
    

    source.setAttribute("src", this.p_filepath.get());    
    source.setAttribute("type", this.p_type.get());

    audio.appendChild(source);

    audio.autoplay = this.p_autoplay.get();
    audio.loop = this.p_loop.get();
    audio.controls = this.p_controls.get();

    container.appendChild(audio);

  }
} 
// O11CORE_audio


/* 
*************************************************************************
* Object O11CORE_Font
*************************************************************************
*/
class O11CORE_font {
  constructor() {
    this.p_fontweight = new O11CORE_prop();
    this.p_fontfamily = new O11CORE_prop();
    this.p_fontsize = new O11CORE_prop();
    this.p_fontstyle = new O11CORE_prop();
    this.p_fontvariant = new O11CORE_prop();
    this.p_fontletterspacing = new O11CORE_prop();

    // object properties defaults
    this.p_fontweight.set("");
    this.p_fontfamily.set("Consolas");
    this.p_fontsize.set("16px");
    this.p_fontstyle.set("");
    this.p_fontvariant.set("");
    this.p_fontletterspacing.set("");
  }

  set_prop2container(container) {

    container.style.fontWeight = this.p_fontweight.get();
    container.style.fontFamily = this.p_fontfamily.get();
    container.style.fontSize = this.p_fontsize.get();
    container.style.fontStyle = this.p_fontstyle.get();
    container.style.fontVariant = this.p_fontvariant.get();
    container.style.fontletterspacing = this.p_fontletterspacing.get();
  }

  set_fontsize(font) {
    let fontsize;

    switch(font) {
      case "xsmall": 
        fontsize ="10px";
        break;
      case "small": 
        fontsize ="12px";
        break;
      case "normal": 
        fontsize ="16px";
        break;
      case "large": 
        fontsize ="18px";
        break;
      case "xlarge": 
        fontsize ="22px";
        break;
      case "big": 
        fontsize ="26px";
        break;
      case "xbig": 
        fontsize ="36px";
        break;
      case "huge": 
        fontsize ="48px";
        break;
      case "xhuge": 
        fontsize ="72px";
        break;
      default: 
        fontsize ="16px";   
    }
    this.p_fontsize.set(fontsize);
  }
}
//end O11CORE_font


/* 
*************************************************************************
* Object O11CORE_link
*************************************************************************
*/
class O11CORE_link {

  constructor() {
    this.p_target = new O11CORE_prop();
    this.p_url = new O11CORE_prop();
    this.p_title = new O11CORE_prop();

    // object properties defaults
    this.p_target.set("_self"); // _self _blank
    this.p_url.set("#");
    this.p_title.set("");
  }

  set_prop2container(container) {
    let a;
          
    a = document.createElement("A");
    a.setAttribute("href", this.p_url.get());  
    a.setAttribute("target", this.p_target.get());
    a.setAttribute("title", this.p_title.get());

    container.appendChild(a);
    
  }
}
//end O11CORE_link